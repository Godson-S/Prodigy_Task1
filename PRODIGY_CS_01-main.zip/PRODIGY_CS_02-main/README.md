This is my second internship task at Prodigy InfoTech. I had to create a very simple image encryption tool by pixel manipulation.
I used basic mathematical operations to be applied at each pixel. Users can provide an encryption key for encrypting as well as decrypting the image.
**But because of its simplicity, encryption can be easily done but the decryption causes loss of quality of image. The decrypted image will not be same as the original one.**
