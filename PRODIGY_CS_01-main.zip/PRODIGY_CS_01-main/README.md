This is the first task I was given during the internship at Prodigy InfoTech.
It is a program in python which uses a very simple encryption algorithm.
User has to specify a `shift value` for encryption or decryption.
This python program encrypts or decrypts a user's message using `Caesar Cipher Algorithm`.

