This is the third task given to me for my cybersecurity internship at Prodigy InfoTech.
This is a simple python code for checking the complexity or strength of a password.
